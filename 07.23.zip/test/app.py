from flask import Flask, render_template

app = Flask(__name__)

@app.route('/<path>')
def view(path= None):
    if path:
        return render_template('%s.html' %path)
    else:
        return render_template('test.html')

@app.route('/')
def index2():
    return render_template('study.html')

if __name__ == '__main__':
    app.run(use_reloader = True, debug = True)


